import dotenv from "dotenv";
import fetch,{ Headers } from "node-fetch";  // Import node-fetch
import { GoogleGenerativeAI } from "@google/generative-ai";

// Bind fetch globally to mimic native fetch API
globalThis.fetch = fetch;
globalThis.Headers = Headers;

dotenv.config();

const genAI = new GoogleGenerativeAI("AIzaSyDgNALel9-kxVxcqKXJRGxhy1IsQC7xZCQ");

async function run() {
    try {
        const model = genAI.getGenerativeModel({ model: "gemini-pro" });
        const prompt = "hello";
        const result = await model.generateContent(prompt);
        const response = await result.response;
        const text = await response.text();
        console.log(text);
    } catch (error) {
        console.error("Error occurred:", error.message);
    }
}

run();
